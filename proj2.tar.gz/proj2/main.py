# Google API Key = AIzaSyCLDWIQPEW3ryJSU9F0ZNyl2LqAdUYoDJw
# Google Engine ID = 40b1f20d99e95e3e4

import sys
import spacy
from bs4 import BeautifulSoup
from spanbert import SpanBERT
import requests
from spacy_help_functions import get_entities, create_entity_pairs
import string

f = open('transcript.txt', 'w')

spanbert = SpanBERT(pretrained_dir="pretrained_spanbert")

if len(sys.argv) != 7:
    sys.exit('Missing parameters')

apiKey = sys.argv[1]
engineID = sys.argv[2]
relation = int(sys.argv[3])
threshold = float(sys.argv[4])
seedQuery = sys.argv[5]
tuplesRequested = int(sys.argv[6])

if tuplesRequested <= 0:
    sys.exit('Number of tuples requested must be greater than 0')
if relation == 1:
    relation ='per:schools_attended'
elif relation == 2:
    relation ='per:employee_of'
elif relation == 3:
    relation = 'per:cities_of_residence'
elif relation == 4:
    relation = 'org:top_members/employees'
else:
    sys.exit('Relation must be an integer between 1-4')

f.write('____\n')
f.write('Parameters:\n')
f.write('Client key  = ' + apiKey + '\n')
f.write('Engine key  = ' + engineID + '\n')    
f.write("Relation    = " + str(relation) + '\n')
f.write("Threshold   = " + str(threshold) + '\n')
f.write("Query       = " + seedQuery + '\n')
f.write("# of Tuples = " + str(tuplesRequested) +'\n')

f.write("Loading necessary libraries; This should take a minute or so ...\n")
nlp = spacy.load("en_core_web_lg")


numOfIterations = 0
numOfIterations += 1
count = 0
relations = {}
relationsUsed = set()
entities_of_interest = ["ORGANIZATION", "PERSON", "LOCATION", "CITY", "STATE_OR_PROVINCE", "COUNTRY"]
visitedLinks = set()

#Continue querying until the number of tuples match or exceed the requested amount of relations
while len(relations) < tuplesRequested:
    f.write(f"=========== Iteration: {numOfIterations} - Query: {seedQuery} ===========\n")
    payload = {'key' : apiKey, 'cx' : engineID, 'q' : seedQuery}
    r = requests.get('https://www.googleapis.com/customsearch/v1', params=payload)
    items = r.json()["items"]
    links = [item['link'] for item in items]
    links = list(set(links))
    


    #Looping through the links to extracting the raw text and find relations
    for idx,l in enumerate(links):

        if l in visitedLinks:
            f.write('Link has already been visited. On to the next one...\n')
            continue
        
        visitedLinks.add(l)
        f.write(f"URL ({idx+1} / 10): {l}\n")
        f.write('\tFetching text from url ... \n\n')
        try:
            r = requests.get(l, timeout = 30)
        except:
            f.write('Unable to fetch URL. Continuing.\n')
            continue
        
        #Extracting the text from webpages, removing tabs and newlines and reducing the size to 20,000 characters
        soup = BeautifulSoup(r.text, 'html.parser')
        text = soup.findAll('p')
        text = [p.get_text().replace('\n', '').replace('\t','') for p in text]
        text = ' '.join(text)
        sizeLimit = min(len(text),20000)
        text = text[0: sizeLimit]
        doc = nlp(text)  

        f.write('\tWebpage length (num characters): ' + str(len(text)) + '\n')
        f.write('\tAnnotating the webpage using spacy...\n')
        
        numOfSentences = 0
        numOfSentencesUsed = 0
        numOfRelations = 0
        numOfRelationsUsed = 0
        
        for _ in doc.sents:
            numOfSentences += 1
        f.write(f"\tExtracted {numOfSentences} sentences. Processing each sentence one by one to check for presence of right pair of named entity types; if so, will run the second pipeline ...\n")
        #for each sentence, find the entity pairs
        for idx,sentence in enumerate(doc.sents):
            
            thisSentenceUsed = False
            if idx % 5 == 0 and idx != 0:
                f.write(f"\tProcessed {idx} / {numOfSentences} sentences\n")
            ents = get_entities(sentence, entities_of_interest)
        
            candidate_pairs = []
            sentence_entity_pairs = create_entity_pairs(sentence, entities_of_interest)
            for ep in sentence_entity_pairs:
                role1 = ep[1][1]
                role2 = ep[2][1]

            #Checking to see if the entities are of interest based on the relation input
                if relation == "per:schools_attended" or relation == "per:employee_of":
                    if role1 == 'PERSON' and role2 == 'ORGANIZATION': 
                        candidate_pairs.append({"tokens": ep[0], "subj": ep[1], "obj": ep[2]})
                    elif role1 == 'ORGANIZATION' and role2 == 'PERSON':
                        candidate_pairs.append({"tokens": ep[0], "subj": ep[2], "obj": ep[1]})
                elif relation == "org:top_members/employees":
                    if role2 == 'PERSON' and role1 == 'ORGANIZATION':
                        candidate_pairs.append({"tokens": ep[0], "subj": ep[1], "obj": ep[2]})
                    elif role2 == 'ORGANIZATION' and role1 == 'PERSON':
                        candidate_pairs.append({"tokens": ep[0], "subj": ep[2], "obj": ep[1]})
                elif relation == "per:cities_of_residence":
                    if role1 == 'PERSON' and role2 in ('LOCATION', 'CITY', 'STATE_OR_PROVINCE', 'COUNTRY'):
                        candidate_pairs.append({"tokens": ep[0], "subj": ep[1], "obj": ep[2]})
                    elif role1 in ('LOCATION', 'CITY', 'STATE_OR_PROVINCE', 'COUNTRY') and role2 == 'PERSON':
                        candidate_pairs.append({"tokens": ep[0], "subj": ep[2], "obj": ep[1]})


            if len(candidate_pairs) == 0:
                continue
            
            # get predictions: list of (relation, confidence) pairs
            relation_preds = spanbert.predict(candidate_pairs)  

            #iterating through the predictions to see if they are not
            #already in set of extracted tuples and meet the confidence threshold
            #if they meet the threshold then add it to the final list of tuples extracted
            for ex, pred in list(zip(candidate_pairs, relation_preds)):
                if pred[0] == relation:
                    if not thisSentenceUsed:
                        thisSentenceUsed = True
                        numOfSentencesUsed += 1
                    f.write('\n')
                    f.write("\t\t=== Extracted Relation ===\n")
                    f.write(f"\t\tSentence: {sentence}\n")
                    f.write(f"\t\tConfidence: {pred[1]} ; Subject : {ex['subj'][0]} ; Objects : {ex['obj'][0]} ;\n")
                    numOfRelations += 1
                    if pred[1] < threshold:
                        f.write('\t\tConfidence is lower than threshold confidence. Ignoring this.\n')
                    else:
                        if (ex["subj"][0], ex["obj"][0]) in relations and relations[(ex["subj"][0], ex["obj"][0])] > pred[1]:
                            f.write('\t\tDuplicate with lower confidence than existing record. Ignoring this.\n')
                        else:
                            numOfRelationsUsed += 1
                            relations[(ex["subj"][0], ex["obj"][0])] = pred[1]
                            f.write("\t\tAdding to set of extracted relations\n")

                    f.write("\t\t==========\n")
                    
        f.write(f"Extracted annotations for  {numOfSentencesUsed}  out of total  {numOfSentences}  sentences\n")
        f.write(f"Relations extracted from this website: {numOfRelationsUsed} (Overall: {numOfRelations})\n")
    
    maxConfidence = 0
    tupleWithMaxConfidence = None

    #Extracting the tuple with the highest confidence to add to the seedQuery
    for tup,conf in relations.items():
        if tup not in relationsUsed and conf > maxConfidence:
            maxConfidence = conf
            tupleWithMaxConfidence = tup

    #if no tuples were extracted exit the program
    if tupleWithMaxConfidence == None:
        f.write('ISE has "stalled" before retrieving k high-confidence tuples\n')
        sys.exit()
    seedQuery = tup[0] + " " + tup[1]
        

    f.write(f"================== ALL RELATIONS for {relation} ({len(relations)}) =================\n")
    relations = dict(sorted(relations.items(), key=lambda item: item[1], reverse=True))
    for i,v in relations.items():
        i = list(i)
        f.write(f"Confidence: {v} \t | Subject: {i[0]} \t | Object: {i[1]}\n")
    
f.write(f"Total # of iterations = {numOfIterations}\n")

#print(apiKey,engineID,relation,threshold,seedQuery,tuplesRequested)


